// D-FLIX PC - main process
// Isme koi bhi Drive/TMDB/download logic nahi hai - woh sab assets/bridge.js
// me hai, jo renderer process ke andar hi (nodeIntegration ke through)
// chalta hai. Yahan sirf window banayi jaati hai.

const { app, BrowserWindow, shell } = require("electron");
const path = require("path");

process.env.ELECTRON_DISABLE_SECURITY_WARNINGS = "true";

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 480,
    height: 860,
    minWidth: 380,
    minHeight: 600,
    backgroundColor: "#050508",
    icon: path.join(__dirname, "assets", "icon.png"),
    title: "D-FLIX",
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      sandbox: false,
      webSecurity: true,
    },
  });

  mainWindow.setMenuBarVisibility(false);
  mainWindow.loadFile(path.join(__dirname, "assets", "index.html"));

  // Koi bhi target="_blank" / window.open() ho to system browser me kholo,
  // Electron ke andar naya window na banaye.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });
}

app.whenReady().then(() => {
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
