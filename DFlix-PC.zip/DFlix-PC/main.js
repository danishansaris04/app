// D-FLIX PC - main process
// Isme koi bhi Drive/TMDB/download logic nahi hai - woh sab assets/bridge.js
// me hai, jo renderer process ke andar hi (nodeIntegration ke through)
// chalta hai. Yahan sirf window banayi jaati hai.

const { app, BrowserWindow, shell } = require("electron");
const path = require("path");

process.env.ELECTRON_DISABLE_SECURITY_WARNINGS = "true";

// -------------------------------------------------------------------------
// PORTABLE DATA FOLDER - login/auth data ab app ke apne folder ke andar
// save hoga (user-data/auth.json), user ke home/AppData me nahi. Isse
// agar poora app ka folder (ya installed .exe waala folder) kisi ko de
// diya jaaye, to usse dubara Google login nahi karna padega.
//   - Dev mode (npm start): DFlix-PC/user-data/
//   - Packaged .exe: exe ke jitne hi folder ke andar user-data/
// -------------------------------------------------------------------------
const dflixDataDir = app.isPackaged
  ? path.join(path.dirname(process.execPath), "user-data")
  : path.join(__dirname, "user-data");
process.env.DFLIX_DATA_DIR = dflixDataDir;


let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 480,
    height: 860,
    minWidth: 380,
    minHeight: 600,
    backgroundColor: "#050508",
    icon: path.join(__dirname, "assets", "icon.png"),
    title: "D-FLIX",
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      sandbox: false,
      webSecurity: true,
    },
  });

  mainWindow.setMenuBarVisibility(false);
  mainWindow.loadFile(path.join(__dirname, "assets", "index.html"));

  // Koi bhi target="_blank" / window.open() ho to system browser me kholo,
  // Electron ke andar naya window na banaye.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });
}

app.whenReady().then(() => {
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
