# D-FLIX PC

Aapke Android "D-FLIX" app ka PC (Windows/Mac/Linux) version — Electron se
bana hai. UI (assets/index.html + assets/app.js) bilkul original jaisa hi
hai; sirf neeche ka "native" layer (jo Android me Java files karti thi) ab
`assets/bridge.js` me plain Node.js se kaam karta hai.

## NAYI CHIZ: DOWNLOAD

Jab bhi koi file ya poori folder download karenge:
1. Wo seedhe aapke computer ke asli **Downloads** folder ke andar ek
   `DFlix` subfolder me save hogi
   (Windows: `C:\Users\<aap>\Downloads\DFlix\...`,
   Mac/Linux: `~/Downloads/DFlix/...`).
2. Folder download karne par Drive jaisi hi nested folder-structure bhi
   wahi bana kar rakhi jaati hai.
3. Saath hi, app ke andar **Downloads tab** me bhi wahi file turant progress
   (%, speed) ke saath dikhti rehti hai — bilkul jaise pehle Android app me
   dikhti thi. Ye do jagah alag-alag "download" nahi hain, ek hi asli file
   hai jo dono jagah nazar aati hai.

## SETUP (pehli baar)

1. [Node.js](https://nodejs.org) install karo (agar pehle se nahi hai) —
   LTS version le lena.
2. Is `DFlix-PC` folder ke andar terminal/cmd kholo aur likho:
   ```
   npm install
   ```
   (Isse Electron download hoga - internet chahiye, ek hi baar karna hai.)
3. App chalane ke liye:
   ```
   npm start
   ```

## LOGIN

- "Login with Google" dabate hi aapka system browser (Chrome/Edge/etc.)
  khulega.
- Google Cloud Console me OAuth client pehle se `http://127.0.0.1:8765/oauth2callback`
  ke liye set hai (wahi jo Android version me tha) — kuch badalne ki
  zaroorat nahi, seedha login ho jaayega.
- Login ke baad refresh token `~/.dflix-pc/auth.json` me save ho jaata hai,
  isliye dubara login nahi maangega.

## VIDEO PLAY

- **Play** (bina download kiye, seedha stream) — app ke andar hi ek video
  player khulta hai. Zyadatar MKV files (H.264/AAC waali) chal jaati hain,
  lekin agar koi unusual codec waali file play na ho, to use pehle
  **Download** karke Downloads tab se dobara play karein — wahan file
  aapke system ke default video player (VLC, Windows Media Player, etc.)
  me khulti hai, jo har format handle kar leta hai.

## WINDOWS 8 PAR CHALANA / .exe BANANA

Naye Electron versions (23 aur upar) sirf Windows 10+ par chalte hain,
isliye is project me jaan-boojh kar **Electron 22** rakha gaya hai — ye
last version hai jo Windows 7/8/8.1 par bhi chalta hai. `package.json` me
ye already set hai, kuch badalna nahi hai.

**Node.js version bhi purana rakhna** (Windows 8 par):
- [Node.js 16 LTS](https://nodejs.org/download/release/latest-v16.x/)
  install karo (naya Node 20/22 kabhi-kabhi Windows 8 par ठीक se nahi
  chalta) - "node-v16.x.x-x64.msi" (64-bit Windows 8 ke liye) ya
  "x86.msi" (32-bit ke liye) le lena.

**Steps (Windows 8 waale PC par hi, ya kisi bhi Windows PC par):**
```
npm install
npm start          -> seedha app chalane ke liye (dev mode)
npm run build:win  -> ek asli .exe installer banane ke liye
```
`npm run build:win` chalane ke baad `dist` folder me
`D-FLIX Setup 1.0.0.exe` milega — usi ko double-click karke install karo,
phir Start Menu se "D-FLIX" khol sakte ho, `npm start` baar baar nahi
chalana padega.

Agar `npm run build:win` Windows 8 par hi fail ho (build tools ki dikkat
kabhi-kabhi purane Windows par aati hai), to koi bhi Windows 10/11 PC par
yehi 2 command (`npm install` phir `npm run build:win`) chala kar `.exe`
bana lo — wahi `.exe` phir Windows 8 wale PC par bhi chalega (Electron 22
khud install honi wali cheez ke andar hi bundled hoti hai).

## NOTE

- App ka poora UI/logic wahi hai jo Android version me tha
  (`assets/app.js` unchanged copy hai) — sirf niche ki "native" layer PC
  ke liye dobara likhi gayi hai.
- Original app do jagah script load karta tha (ek local `app.js`, ek
  `danishansaris04.github.io/dflixadmin/app.js` se remote) — is PC version
  me sirf local, bundled copy use ki gayi hai, taaki app third-party
  hosting par depend na kare aur offline bhi reliably chale.
