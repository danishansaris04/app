# D-FLIX PC

Aapke Android "D-FLIX" app ka PC (Windows/Mac/Linux) version — Electron se
bana hai. UI (assets/index.html + assets/app.js) bilkul original jaisa hi
hai; sirf neeche ka "native" layer (jo Android me Java files karti thi) ab
`assets/bridge.js` me plain Node.js se kaam karta hai.

## NAYI CHIZ: DOWNLOAD

Jab bhi koi file ya poori folder download karenge:
1. Wo seedhe aapke computer ke asli **Downloads** folder ke andar ek
   `DFlix` subfolder me save hogi
   (Windows: `C:\Users\<aap>\Downloads\DFlix\...`,
   Mac/Linux: `~/Downloads/DFlix/...`).
2. Folder download karne par Drive jaisi hi nested folder-structure bhi
   wahi bana kar rakhi jaati hai.
3. Saath hi, app ke andar **Downloads tab** me bhi wahi file turant progress
   (%, speed) ke saath dikhti rehti hai — bilkul jaise pehle Android app me
   dikhti thi. Ye do jagah alag-alag "download" nahi hain, ek hi asli file
   hai jo dono jagah nazar aati hai.

## SETUP (pehli baar)

1. [Node.js](https://nodejs.org) install karo (agar pehle se nahi hai) —
   LTS version le lena.
2. Is `DFlix-PC` folder ke andar terminal/cmd kholo aur likho:
   ```
   npm install
   ```
   (Isse Electron download hoga - internet chahiye, ek hi baar karna hai.)
3. App chalane ke liye:
   ```
   npm start
   ```

## LOGIN

- "Login with Google" dabate hi aapka system browser (Chrome/Edge/etc.)
  khulega.
- Google Cloud Console me OAuth client pehle se `http://127.0.0.1:8765/oauth2callback`
  ke liye set hai (wahi jo Android version me tha) — kuch badalne ki
  zaroorat nahi, seedha login ho jaayega.
- Login ke baad refresh token app ke **apne folder** ke andar
  `user-data/auth.json` me save hota hai (pehle ye `~/.dflix-pc/` yaani
  aapke Windows user profile me save hota tha — ab nahi). Isliye:
  - Dubara login nahi maangega.
  - Agar poora `DFlix-PC` folder (ya installed app waala folder) kisi
    aur PC/user ko de diya jaaye, to wahan bhi login already-done milega.

### Agar login pe click karne par kuch response na aaye

Sabse common wajah **port 8765 pehle se busy hona** hai (jaise D-FLIX
pehle se background me chal raha ho). Ab app is case me toast/status
dikha degi. Agar phir bhi fas jaaye:

1. App ko poora band karein (Task Manager me bhi check kar lein koi
   purana D-FLIX process to nahi chal raha) aur dobara kholein.
2. `Ctrl+Shift+I` dabakar DevTools kholein aur "Console" tab check
   karein — waha `[DFlix] ...` se shuru hone waale error messages
   dikhenge (jaise `redirect_uri_mismatch`, `access_denied` — inse
   pata chalega Google Cloud Console side ka masla hai ya kuch aur).
3. Login button click karne ke 45 second baad bhi response na aaye to
   status text me hi message dikh jaayega.

## VIDEO PLAY

- **Play** (bina download kiye, seedha stream) — ab file **VLC** me khulti
  hai (agar VLC installed hai to). VLC nahi mila to automatically app
  ke andar wale built-in player me chalegi.
- Download karke Downloads tab se play karne par bhi pehle VLC try
  hoga, warna system ka default video player khulega.
- VLC free hai: https://www.videolan.org/vlc/

## WINDOWS 8 PAR CHALANA / .exe BANANA

Naye Electron versions (23 aur upar) sirf Windows 10+ par chalte hain,
isliye is project me jaan-boojh kar **Electron 22** rakha gaya hai — ye
last version hai jo Windows 7/8/8.1 par bhi chalta hai. `package.json` me
ye already set hai, kuch badalna nahi hai.

**Node.js version bhi purana rakhna** (Windows 8 par):
- [Node.js 16 LTS](https://nodejs.org/download/release/latest-v16.x/)
  install karo (naya Node 20/22 kabhi-kabhi Windows 8 par ठीक se nahi
  chalta) - "node-v16.x.x-x64.msi" (64-bit Windows 8 ke liye) ya
  "x86.msi" (32-bit ke liye) le lena.

**Steps (Windows 8 waale PC par hi, ya kisi bhi Windows PC par):**
```
npm install
npm start          -> seedha app chalane ke liye (dev mode)
npm run build:win  -> ek asli .exe installer banane ke liye
```
`npm run build:win` chalane ke baad `dist` folder me
`D-FLIX Setup 1.0.0.exe` milega — usi ko double-click karke install karo,
phir Start Menu se "D-FLIX" khol sakte ho, `npm start` baar baar nahi
chalana padega.

Agar `npm run build:win` Windows 8 par hi fail ho (build tools ki dikkat
kabhi-kabhi purane Windows par aati hai), to koi bhi Windows 10/11 PC par
yehi 2 command (`npm install` phir `npm run build:win`) chala kar `.exe`
bana lo — wahi `.exe` phir Windows 8 wale PC par bhi chalega (Electron 22
khud install honi wali cheez ke andar hi bundled hoti hai).

## NOTE

- App ka poora UI/logic wahi hai jo Android version me tha
  (`assets/app.js` unchanged copy hai) — sirf niche ki "native" layer PC
  ke liye dobara likhi gayi hai.
- Original app do jagah script load karta tha (ek local `app.js`, ek
  `danishansaris04.github.io/dflixadmin/app.js` se remote) — is PC version
  me sirf local, bundled copy use ki gayi hai, taaki app third-party
  hosting par depend na kare aur offline bhi reliably chale.
