// ==========================================================================
// D-FLIX PC - "window.Android" bridge
// Original Android app me ye sab kaam Java files (TokenManager, DriveHelper,
// LocalServer, LocalDownloadManager, TmdbHelper/PosterCache, WebAppInterface)
// karte the. Yahan PC par wahi sab kaam is ek file me, plain Node.js se
// (koi extra npm package nahi chahiye) - assets/app.js bilkul unchanged hai,
// usse pata bhi nahi chalta ki neeche Android nahi, Node chal raha hai.
// ==========================================================================

const https = require("https");
const http = require("http");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { shell } = require("electron");

// -------------------------------------------------------------------------
// CONFIG (TokenManager.java se liya gaya - same Google Cloud project)
// -------------------------------------------------------------------------
const CLIENT_ID = "89188069759-chhqnlnbggmt0n6el64he8cm940dcg24.apps.googleusercontent.com";
const CLIENT_SECRET = "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";
const PORT = 8765;
const REDIRECT_URI = "http://127.0.0.1:" + PORT + "/oauth2callback";
const SCOPE = "https://www.googleapis.com/auth/drive.readonly";
const LOCKED_ROOT_FOLDER_ID = "17s88x00QQXAnTQtFWasBIOcgRqziTEnQ";
const TMDB_API_KEY = "16b0f944d64a43298cf3ce5fc5852ffb";
const TMDB_IMG_POSTER = "https://image.tmdb.org/t/p/w342";
const TMDB_IMG_BACKDROP = "https://image.tmdb.org/t/p/w780";

// -------------------------------------------------------------------------
// small https/http helpers (no dependencies)
// -------------------------------------------------------------------------
function httpsJson(hostname, urlPath, headers) {
  return new Promise((resolve, reject) => {
    const req = https.request(
      { hostname, path: urlPath, method: "GET", headers: headers || {} },
      (res) => {
        let body = "";
        res.on("data", (c) => (body += c));
        res.on("end", () => {
          try {
            resolve(JSON.parse(body));
          } catch (e) {
            reject(new Error("bad_json_response"));
          }
        });
      }
    );
    req.on("error", reject);
    req.end();
  });
}

function httpsPostForm(hostname, urlPath, formBody) {
  return new Promise((resolve, reject) => {
    const bodyBuf = Buffer.from(formBody, "utf8");
    const req = https.request(
      {
        hostname,
        path: urlPath,
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "Content-Length": bodyBuf.length,
        },
      },
      (res) => {
        let body = "";
        res.on("data", (c) => (body += c));
        res.on("end", () => {
          try {
            resolve(JSON.parse(body));
          } catch (e) {
            reject(new Error("bad_json_response"));
          }
        });
      }
    );
    req.on("error", reject);
    req.write(bodyBuf);
    req.end();
  });
}

// -------------------------------------------------------------------------
// TOKEN STORE (TokenManager.java jaisa) - SharedPreferences ki jagah ek
// chhoti si JSON file, user ke home folder me.
// -------------------------------------------------------------------------
const authDir = path.join(os.homedir(), ".dflix-pc");
const authFile = path.join(authDir, "auth.json");

function ensureAuthDir() {
  if (!fs.existsSync(authDir)) fs.mkdirSync(authDir, { recursive: true });
}

function loadAuth() {
  try {
    return JSON.parse(fs.readFileSync(authFile, "utf8"));
  } catch (e) {
    return {};
  }
}

function saveAuth(data) {
  ensureAuthDir();
  fs.writeFileSync(authFile, JSON.stringify(data), "utf8");
}

const TokenStore = {
  isLoggedIn() {
    return !!loadAuth().refresh_token;
  },
  logout() {
    saveAuth({});
  },
  saveTokens(accessToken, refreshToken, expiresInSeconds) {
    const data = loadAuth();
    data.access_token = accessToken;
    data.expires_at = Date.now() + expiresInSeconds * 1000 - 60000;
    if (refreshToken) data.refresh_token = refreshToken;
    saveAuth(data);
  },
  async getValidAccessToken() {
    const data = loadAuth();
    if (data.access_token && Date.now() < (data.expires_at || 0)) {
      return data.access_token;
    }
    if (!data.refresh_token) return null;

    const body =
      "client_id=" + encodeURIComponent(CLIENT_ID) +
      "&client_secret=" + encodeURIComponent(CLIENT_SECRET) +
      "&refresh_token=" + encodeURIComponent(data.refresh_token) +
      "&grant_type=refresh_token";

    try {
      const json = await httpsPostForm("oauth2.googleapis.com", "/token", body);
      if (!json.access_token) return null;
      this.saveTokens(json.access_token, null, json.expires_in || 3600);
      return json.access_token;
    } catch (e) {
      return null;
    }
  },
  async exchangeCodeForTokens(code) {
    const body =
      "code=" + encodeURIComponent(code) +
      "&client_id=" + encodeURIComponent(CLIENT_ID) +
      "&client_secret=" + encodeURIComponent(CLIENT_SECRET) +
      "&redirect_uri=" + encodeURIComponent(REDIRECT_URI) +
      "&grant_type=authorization_code";
    try {
      const json = await httpsPostForm("oauth2.googleapis.com", "/token", body);
      if (!json.access_token) return false;
      this.saveTokens(json.access_token, json.refresh_token || null, json.expires_in || 3600);
      return true;
    } catch (e) {
      return false;
    }
  },
};

// -------------------------------------------------------------------------
// DRIVE API (DriveHelper.java jaisa)
// -------------------------------------------------------------------------
const Drive = {
  async listFiles(token, folderId) {
    const parent = folderId || LOCKED_ROOT_FOLDER_ID;
    const q = encodeURIComponent("'" + parent + "' in parents and trashed=false");
    const fields = encodeURIComponent("files(id,name,mimeType,size,modifiedTime)");
    const p = "/drive/v3/files?q=" + q + "&fields=" + fields + "&pageSize=200&orderBy=folder,name_natural";
    return httpsJson("www.googleapis.com", p, { Authorization: "Bearer " + token });
  },

  async collectFolderIdsRecursive(token, rootId) {
    const allowed = new Set([rootId]);
    const queue = [rootId];
    let idx = 0;
    while (idx < queue.length) {
      const parent = queue[idx++];
      const q = encodeURIComponent(
        "'" + parent + "' in parents and trashed=false and mimeType='application/vnd.google-apps.folder'"
      );
      const p = "/drive/v3/files?q=" + q + "&fields=" + encodeURIComponent("files(id)") + "&pageSize=200";
      const json = await httpsJson("www.googleapis.com", p, { Authorization: "Bearer " + token });
      (json.files || []).forEach((f) => {
        if (!allowed.has(f.id)) {
          allowed.add(f.id);
          queue.push(f.id);
        }
      });
    }
    return allowed;
  },

  async searchFiles(token, keyword) {
    const allowed = await this.collectFolderIdsRecursive(token, LOCKED_ROOT_FOLDER_ID);
    const q = encodeURIComponent("name contains '" + keyword.replace(/'/g, "\\'") + "' and trashed=false");
    const fields = encodeURIComponent("files(id,name,mimeType,size,modifiedTime,parents)");
    const p = "/drive/v3/files?q=" + q + "&fields=" + fields + "&pageSize=200";
    const json = await httpsJson("www.googleapis.com", p, { Authorization: "Bearer " + token });
    const files = (json.files || []).filter(
      (f) => f.parents && f.parents.some((par) => allowed.has(par))
    );
    return { files };
  },

  async resolveActualFileId(token, fileId) {
    let currentId = fileId;
    for (let hop = 0; hop < 5; hop++) {
      const fields = encodeURIComponent("id,mimeType,shortcutDetails");
      const p = "/drive/v3/files/" + currentId + "?fields=" + fields;
      const meta = await httpsJson("www.googleapis.com", p, { Authorization: "Bearer " + token });
      if (meta.mimeType !== "application/vnd.google-apps.shortcut") return currentId;
      const targetId = meta.shortcutDetails && meta.shortcutDetails.targetId;
      if (!targetId) return currentId;
      currentId = targetId;
    }
    return currentId;
  },

  // Range-aware stream, "res" (https.IncomingMessage) callback ke through milta hai
  openFileStream(token, fileId, rangeHeader) {
    return new Promise((resolve, reject) => {
      const headers = { Authorization: "Bearer " + token };
      if (rangeHeader) headers.Range = rangeHeader;
      const req = https.request(
        {
          hostname: "www.googleapis.com",
          path: "/drive/v3/files/" + fileId + "?alt=media",
          method: "GET",
          headers,
        },
        (res) => resolve(res)
      );
      req.on("error", reject);
      req.end();
    });
  },

  async collectFilesRecursive(token, folderId, out, depth, pathSoFar) {
    if (depth > 8) return;
    const raw = await this.listFiles(token, folderId);
    const files = raw.files || [];
    for (const f of files) {
      if (f.mimeType === "application/vnd.google-apps.folder") {
        await this.collectFilesRecursive(token, f.id, out, depth + 1, pathSoFar.concat([f.name]));
      } else {
        f.subPath = pathSoFar;
        out.push(f);
      }
    }
  },
};

// -------------------------------------------------------------------------
// TMDB (TmdbHelper.java jaisa) - poster/backdrop URL seedhe TMDB se milta
// hai, isliye <img> tag khud hi image load kar sakta hai (base64 karne ki
// zaroorat nahi, ye sirf Android WebView ki limitation thi).
// -------------------------------------------------------------------------
const JUNK_TOKENS = [
  "1080p", "720p", "480p", "2160p", "4k", "8k", "hdcam", "hdrip", "dvdrip",
  "webrip", "web dl", "webdl", "bluray", "blu ray", "brrip", "bdrip",
  "hdtv", "x264", "x265", "hevc", "h264", "h265", "aac", "ac3", "dts",
  "esubs", "esub", "subbed", "dual audio", "multi audio", "dubbed",
  "hindi", "english", "tamil", "telugu", "kannada", "malayalam", "korean",
  "proper", "extended", "uncut", "remastered", "nf", "amzn", "hmax",
  "yify", "yts", "rarbg", "galaxytv", "psa", "org",
];

const Tmdb = {
  parseFilename(rawName) {
    let name = rawName.replace(/\.(mkv|mp4|avi|mov|wmv|flv|webm|m4v|ts|3gp)$/i, "");

    let year = null;
    const yearMatch = name.match(/\b(19\d{2}|20\d{2})\b/);
    if (yearMatch) year = yearMatch[1];

    const seMatch = name.match(/\bS\d{1,2}\s?E\d{1,3}\b/i);
    const seasonMatch = name.match(/\bSeason\s?\d{1,2}\b/i);

    let guessedType, titleSource;
    if (seMatch) {
      guessedType = "tv";
      titleSource = name.substring(0, seMatch.index);
    } else if (seasonMatch) {
      guessedType = "tv";
      titleSource = name.substring(0, seasonMatch.index);
    } else {
      guessedType = "movie";
      titleSource = name;
    }

    titleSource = titleSource.replace(/[\[({][^\[\]({)}]*[\])}]/g, " ");
    titleSource = titleSource.replace(/[._-]/g, " ");
    for (const junk of JUNK_TOKENS) {
      titleSource = titleSource.replace(new RegExp("\\b" + junk.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b", "gi"), " ");
    }
    titleSource = titleSource.replace(/\b(19\d{2}|20\d{2})\b/g, " ");
    titleSource = titleSource.replace(/\b\d+(\.\d+)?\s?(MB|GB|KB)\b/gi, " ");
    titleSource = titleSource.replace(/\s+/g, " ").trim();
    titleSource = titleSource.replace(/^[\s\-:,.]+|[\s\-:,.]+$/g, "").trim();

    return { title: titleSource, year, guessedType };
  },

  async searchMovie(title, year) {
    let p = "/3/search/movie?api_key=" + TMDB_API_KEY + "&query=" + encodeURIComponent(title);
    if (year) p += "&year=" + year;
    const json = await httpsJson("api.themoviedb.org", p, {});
    const results = json.results || [];
    if (results.length > 0) {
      const first = results[0];
      return { posterPath: first.poster_path || null, backdropPath: first.backdrop_path || null };
    }
    if (year) return this.searchMovie(title, null);
    return { posterPath: null, backdropPath: null };
  },

  async searchTv(title) {
    const p = "/3/search/tv?api_key=" + TMDB_API_KEY + "&query=" + encodeURIComponent(title);
    const json = await httpsJson("api.themoviedb.org", p, {});
    const results = json.results || [];
    if (results.length > 0) {
      const first = results[0];
      return { posterPath: first.poster_path || null, backdropPath: first.backdrop_path || null };
    }
    return { posterPath: null, backdropPath: null };
  },

  async resolve(rawFileName, wantBackdrop) {
    try {
      const info = this.parseFilename(rawFileName);
      if (!info.title) return null;
      const result =
        info.guessedType === "tv" ? await this.searchTv(info.title) : await this.searchMovie(info.title, info.year);
      const pathPart = wantBackdrop ? result.backdropPath : result.posterPath;
      if (!pathPart) return null;
      return (wantBackdrop ? TMDB_IMG_BACKDROP : TMDB_IMG_POSTER) + pathPart;
    } catch (e) {
      return null;
    }
  },
};

// -------------------------------------------------------------------------
// LOCAL SERVER (LocalServer.java jaisa) - http://127.0.0.1:8765
//   /oauth2callback  -> Google login redirect yahin aata hai
//   /stream/{fileId}  -> video ka live stream (Range-aware)
// -------------------------------------------------------------------------
function startLocalServer() {
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, "http://127.0.0.1:" + PORT);

      if (url.pathname === "/oauth2callback") {
        const code = url.searchParams.get("code");
        if (!code) {
          res.writeHead(400, { "Content-Type": "text/html" });
          res.end("<h2>Login failed. No code received.</h2>");
          if (window.onLoginComplete) window.onLoginComplete(false);
          return;
        }
        const ok = await TokenStore.exchangeCodeForTokens(code);
        res.writeHead(ok ? 200 : 500, { "Content-Type": "text/html" });
        res.end(
          ok
            ? "<html><body style='font-family:sans-serif;text-align:center;margin-top:60px'><h2>Login successful \u2705</h2><p>Ab app par wapas jaayein.</p></body></html>"
            : "<h2>Login failed while exchanging token.</h2>"
        );
        if (window.onLoginComplete) window.onLoginComplete(ok);
        return;
      }

      if (url.pathname.startsWith("/stream/")) {
        const fileId = url.pathname.substring("/stream/".length);
        const token = await TokenStore.getValidAccessToken();
        if (!token) {
          res.writeHead(401, { "Content-Type": "text/plain" });
          res.end("Not logged in");
          return;
        }
        const realFileId = await Drive.resolveActualFileId(token, fileId);
        const rangeHeader = req.headers.range || null;
        const driveRes = await Drive.openFileStream(token, realFileId, rangeHeader);

        if (driveRes.statusCode === 200 || driveRes.statusCode === 206) {
          const headers = {
            "Content-Type": "video/x-matroska",
            "Accept-Ranges": "bytes",
          };
          if (driveRes.headers["content-range"]) headers["Content-Range"] = driveRes.headers["content-range"];
          if (driveRes.headers["content-length"]) headers["Content-Length"] = driveRes.headers["content-length"];
          res.writeHead(driveRes.statusCode, headers);
          driveRes.pipe(res);
        } else {
          res.writeHead(driveRes.statusCode, { "Content-Type": "text/plain" });
          res.end("Drive error: " + driveRes.statusCode);
        }
        return;
      }

      res.writeHead(404, { "Content-Type": "text/plain" });
      res.end("Not found");
    } catch (e) {
      try {
        res.writeHead(500, { "Content-Type": "text/plain" });
        res.end("Server error: " + e.message);
      } catch (e2) {}
    }
  });

  server.on("error", (e) => {
    // Agar app dobara load hui (reload) aur port pehle se hamare hi
    // process me use ho raha hai, to ignore kar do - server chal hi raha hai.
    if (e.code !== "EADDRINUSE") console.error("Local server error:", e);
  });

  server.listen(PORT, "127.0.0.1");
  return server;
}

if (!global.__dflixLocalServer) {
  global.__dflixLocalServer = startLocalServer();
}

// -------------------------------------------------------------------------
// DOWNLOAD MANAGER (LocalDownloadManager.java jaisa) - lekin files ab
// COMPUTER KE ASLI "Downloads" FOLDER me jaati hain (Downloads/DFlix/...),
// taaki koi bhi file manager/Explorer/Finder se seedhe dikhein.
// -------------------------------------------------------------------------
const downloadsRoot = path.join(os.homedir(), "Downloads", "DFlix");
const indexFile = path.join(downloadsRoot, ".dflix-index.json");

function ensureDownloadsRoot() {
  if (!fs.existsSync(downloadsRoot)) fs.mkdirSync(downloadsRoot, { recursive: true });
}

function loadDlIndex() {
  try {
    return JSON.parse(fs.readFileSync(indexFile, "utf8"));
  } catch (e) {
    return {};
  }
}

function saveDlIndex(idx) {
  ensureDownloadsRoot();
  fs.writeFileSync(indexFile, JSON.stringify(idx), "utf8");
}

function sanitize(name) {
  return String(name).replace(/[\\/:*?"<>|]/g, "_");
}

const DownloadManager = {
  tasks: new Map(), // fileId -> { res, cancelled }

  relPathFor(fileId, fileName, subPath) {
    const idx = loadDlIndex();
    if (idx[fileId] && (!subPath || subPath.length === 0)) {
      return idx[fileId]; // purana path preserve karo (retry / bina subPath ke dobara call)
    }
    const parts = (subPath || []).map(sanitize).concat([sanitize(fileName)]);
    const rel = path.join(...parts);
    idx[fileId] = rel;
    saveDlIndex(idx);
    return rel;
  },

  fileFor(fileId) {
    const idx = loadDlIndex();
    if (!idx[fileId]) return null;
    return path.join(downloadsRoot, idx[fileId]);
  },

  start(fileId, fileName, subPath) {
    if (this.tasks.has(fileId)) return; // pehle se chal rahi hai

    ensureDownloadsRoot();
    const rel = this.relPathFor(fileId, fileName, subPath);
    const outFile = path.join(downloadsRoot, rel);
    const tmpFile = outFile + ".part";
    fs.mkdirSync(path.dirname(outFile), { recursive: true });

    const task = { cancelled: false, req: null };
    this.tasks.set(fileId, task);

    const streamUrl = "http://127.0.0.1:" + PORT + "/stream/" + fileId;
    const out = fs.createWriteStream(tmpFile);

    const req = http.get(streamUrl, (res) => {
      task.req = req;
      if (res.statusCode !== 200 && res.statusCode !== 206) {
        out.close();
        try { fs.unlinkSync(tmpFile); } catch (e) {}
        this.tasks.delete(fileId);
        if (window.onDownloadError) window.onDownloadError(fileId, "HTTP " + res.statusCode);
        return;
      }

      const totalBytes = parseInt(res.headers["content-length"] || "0", 10);
      let received = 0;
      let lastReportTime = Date.now();
      let bytesSinceLastReport = 0;

      res.on("data", (chunk) => {
        if (task.cancelled) return;
        out.write(chunk);
        received += chunk.length;
        bytesSinceLastReport += chunk.length;

        const now = Date.now();
        const elapsed = now - lastReportTime;
        if (elapsed >= 500) {
          const speed = bytesSinceLastReport / (elapsed / 1000);
          if (window.onDownloadProgress) window.onDownloadProgress(fileId, received, totalBytes, Math.round(speed));
          lastReportTime = now;
          bytesSinceLastReport = 0;
        }
      });

      res.on("end", () => {
        out.end();
        this.tasks.delete(fileId);
        if (task.cancelled) {
          try { fs.unlinkSync(tmpFile); } catch (e) {}
          if (window.onDownloadCancelled) window.onDownloadCancelled(fileId);
        } else {
          try {
            fs.renameSync(tmpFile, outFile);
          } catch (e) {}
          if (window.onDownloadProgress) {
            window.onDownloadProgress(fileId, received, totalBytes > 0 ? totalBytes : received, 0);
          }
          if (window.onDownloadComplete) window.onDownloadComplete(fileId);
        }
      });

      res.on("error", (err) => {
        out.end();
        this.tasks.delete(fileId);
        try { fs.unlinkSync(tmpFile); } catch (e) {}
        if (task.cancelled) {
          if (window.onDownloadCancelled) window.onDownloadCancelled(fileId);
        } else {
          if (window.onDownloadError) window.onDownloadError(fileId, err.message || "unknown_error");
        }
      });
    });

    req.on("error", (err) => {
      out.end();
      this.tasks.delete(fileId);
      try { fs.unlinkSync(tmpFile); } catch (e) {}
      if (task.cancelled) {
        if (window.onDownloadCancelled) window.onDownloadCancelled(fileId);
      } else {
        if (window.onDownloadError) window.onDownloadError(fileId, err.message || "unknown_error");
      }
    });

    task.req = req;
  },

  cancel(fileId) {
    const task = this.tasks.get(fileId);
    if (task) {
      task.cancelled = true;
      if (task.req) task.req.destroy();
    }
  },

  deleteSavedFile(fileId) {
    this.cancel(fileId);
    const p = this.fileFor(fileId);
    if (p) {
      try { fs.unlinkSync(p); } catch (e) {}
      try { fs.unlinkSync(p + ".part"); } catch (e) {}
    }
    const idx = loadDlIndex();
    delete idx[fileId];
    saveDlIndex(idx);
  },
};

// -------------------------------------------------------------------------
// IN-APP VIDEO PLAYER (dflixplayer external app ki jagah - PC par ek
// built-in overlay player use karte hain)
// -------------------------------------------------------------------------
function ensurePlayerOverlay() {
  let overlay = document.getElementById("dflixPcPlayerOverlay");
  if (overlay) return overlay;

  overlay = document.createElement("div");
  overlay.id = "dflixPcPlayerOverlay";
  overlay.style.cssText =
    "position:fixed;inset:0;z-index:99999;background:#000;display:none;align-items:center;justify-content:center;flex-direction:column;";

  const closeBtn = document.createElement("button");
  closeBtn.textContent = "\u2715 Close";
  closeBtn.style.cssText =
    "position:absolute;top:14px;right:14px;z-index:2;background:rgba(20,20,20,0.85);color:#fff;border:1px solid rgba(255,255,255,0.2);border-radius:8px;padding:8px 14px;font-size:14px;cursor:pointer;";
  closeBtn.onclick = () => {
    video.pause();
    video.src = "";
    overlay.style.display = "none";
  };

  const titleEl = document.createElement("div");
  titleEl.id = "dflixPcPlayerTitle";
  titleEl.style.cssText = "position:absolute;top:16px;left:16px;color:#fff;font-size:14px;opacity:0.85;max-width:60%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;";

  const video = document.createElement("video");
  video.id = "dflixPcPlayerVideo";
  video.controls = true;
  video.autoplay = true;
  video.style.cssText = "max-width:100%;max-height:100%;width:100%;height:100%;background:#000;";

  const hint = document.createElement("div");
  hint.style.cssText = "position:absolute;bottom:14px;left:16px;color:#8e8e93;font-size:12px;";
  hint.textContent = "Agar video play nahi ho raha, to pehle Download karke phir Downloads tab se play karein.";

  overlay.appendChild(closeBtn);
  overlay.appendChild(titleEl);
  overlay.appendChild(video);
  overlay.appendChild(hint);
  document.body.appendChild(overlay);
  return overlay;
}

function playInAppStream(fileId, fileName) {
  const overlay = ensurePlayerOverlay();
  const video = document.getElementById("dflixPcPlayerVideo");
  const titleEl = document.getElementById("dflixPcPlayerTitle");
  titleEl.textContent = fileName || "";
  video.src = "http://127.0.0.1:" + PORT + "/stream/" + fileId;
  overlay.style.display = "flex";
  video.play().catch(() => {});
}

// -------------------------------------------------------------------------
// ANDROID BRIDGE OBJECT - app.js isi object ko "Android.xxx(...)" karke
// call karta hai, bilkul waise hi jaise Android WebView me hota tha.
// -------------------------------------------------------------------------
window.Android = {
  isLoggedIn() {
    return TokenStore.isLoggedIn();
  },

  login() {
    const authUrl =
      "https://accounts.google.com/o/oauth2/v2/auth" +
      "?client_id=" + CLIENT_ID +
      "&redirect_uri=" + encodeURIComponent(REDIRECT_URI) +
      "&response_type=code" +
      "&access_type=offline" +
      "&prompt=consent" +
      "&scope=" + encodeURIComponent(SCOPE);
    shell.openExternal(authUrl);
  },

  logout() {
    TokenStore.logout();
  },

  async listFiles(folderId, jsCallbackName) {
    try {
      const token = await TokenStore.getValidAccessToken();
      if (!token) { window[jsCallbackName]({ error: "not_logged_in" }); return; }
      const result = await Drive.listFiles(token, folderId);
      window[jsCallbackName](result);
    } catch (e) {
      window[jsCallbackName]({ error: e.message || "unknown_error" });
    }
  },

  async searchFiles(keyword, jsCallbackName) {
    try {
      const token = await TokenStore.getValidAccessToken();
      if (!token) { window[jsCallbackName]({ error: "not_logged_in" }); return; }
      const result = await Drive.searchFiles(token, keyword);
      window[jsCallbackName](result);
    } catch (e) {
      window[jsCallbackName]({ error: e.message || "unknown_error" });
    }
  },

  async resolvePoster(rawFileName, requestId) {
    const url = await Tmdb.resolve(rawFileName, false);
    if (window.onPosterResolved) window.onPosterResolved(requestId, url);
  },

  async resolveBackdrop(rawFileName, requestId) {
    const url = await Tmdb.resolve(rawFileName, true);
    if (window.onPosterResolved) window.onPosterResolved(requestId, url);
  },

  openFile(fileId, fileName) {
    playInAppStream(fileId, fileName);
  },

  playLocalFile(fileId, fileName) {
    const p = DownloadManager.fileFor(fileId);
    if (!p || !fs.existsSync(p)) {
      if (window.showToast) window.showToast("Ye file abhi download nahi hui hai");
      return;
    }
    shell.openPath(p);
  },

  downloadFile(fileId, fileName) {
    DownloadManager.start(fileId, fileName, []);
  },

  cancelDownload(fileId) {
    DownloadManager.cancel(fileId);
  },

  deleteDownloadedFile(fileId, fileName) {
    DownloadManager.deleteSavedFile(fileId);
  },

  async downloadFolder(folderId, folderName) {
    try {
      const token = await TokenStore.getValidAccessToken();
      if (!token) {
        if (window.showToast) window.showToast("Pehle login karein");
        return;
      }
      const queued = [];
      await Drive.collectFilesRecursive(token, folderId, queued, 0, []);

      if (queued.length === 0) {
        if (window.showToast) window.showToast("Is folder me koi file nahi mili");
        return;
      }

      if (window.onFolderDownloadQueued) {
        window.onFolderDownloadQueued(JSON.stringify(queued), folderName);
      }
      queued.forEach((f) => {
        DownloadManager.start(f.id, f.name, [folderName].concat(f.subPath || []));
      });
    } catch (e) {
      if (window.showToast) window.showToast("Folder download start nahi ho paya");
    }
  },
};
